using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Threading;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack)
        {
            string sRefreshURL = Request.Url.ToString() + "?text=" + tb.Text;
            mtaRefresh.Attributes.Add("http-equiv", "refresh"); 
            mtaRefresh.Attributes.Add("content", "0;url=" + sRefreshURL);
            frmMain.Visible = false;
            divWait.Visible = true;
        }
        else
        {
            tb.Text = Request.QueryString["text"];
            if (!string.IsNullOrEmpty(tb.Text))
            {
                tb.Text = tb.Text.Remove(0, 6); //?text=
                for (int i = 0; i < 10000; i++)
                {
                    NoL.Text += i.ToString() + " " + tb.Text + " ";
                }
                divResult.Visible = true;
            }
            else
            {
                frmMain.Visible = true;
            }
        }
    }

    protected void btn_OnClick(object sender, EventArgs e)
    {
        NoL.Text = tb.Text;
    }
}
